from __future__ import absolute_import, division, print_function

from ADNet import operation
import torch
import data_loader as loader
import warnings
import scipy.io as scio

warnings.filterwarnings('ignore')

dataset = loader.FLOW
[voltage, CirS_kong, P_map, CG] = loader.load_data(dataset)

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
CUDA = torch.cuda.is_available()
print("On GPU: ", CUDA)

if CUDA :
    dtype = torch.cuda.FloatTensor
else:
    dtype = torch.FloatTensor


X = torch.Tensor(CG).to(device)
Y = torch.Tensor(voltage).to(device)
CirS_kong = torch.Tensor(CirS_kong).to(device)
P = torch.Tensor(P_map).to(torch.bool).to(device)

operation = operation(X, Y, CirS_kong, P, max_epoch=600, learning_rate=10**-3, device=device, alpha_tv = 1e-2, dtype=dtype)
recons = operation.run()
recons = recons.reshape(32, 32)
recons = recons.cpu()
recons = recons.detach().numpy()
scio.savemat("recons" + '.mat', {'recons': recons})
print(recons)