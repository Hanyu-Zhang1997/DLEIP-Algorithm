import scipy.io as scio
import numpy as np


FLOW = 'FLOW1024'

def load_data(name):
    path = 'data/{}.mat'.format(name)
    data = scio.loadmat(path)
    X = data['X']
    X = X.astype(np.float32)
    Y = data['Y']
    Y = Y.astype(np.float32)
    P = data['P']
    P = P.astype(np.float32)
    CG = data['CG']
    CG = CG.astype(np.float32)
    return X, Y, P, CG
