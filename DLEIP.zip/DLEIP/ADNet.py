
from __future__ import absolute_import, division, print_function
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

import torch
import numpy as np
import torch.nn as nn


class ADNet(nn.Module):
    def __init__(self, channels, num_of_layers=15):
        super(ADNet, self).__init__()
        kernel_size = 3
        padding = 1
        features = 128
        groups =1

        '''
        #self.gamma = nn.Parameter(torch.zeros(1))
        '''
        self.conv1_1 = nn.Sequential(nn.Conv2d(in_channels=channels,out_channels=features,kernel_size=kernel_size,padding=padding,groups=groups,bias=False),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_2 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=2,groups=groups,bias=False,dilation=2),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_3 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=1,groups=groups,bias=False),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_4 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=1,groups=groups,bias=False),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_5 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=2,groups=groups,bias=False,dilation=2),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_6 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=1,groups=groups,bias=False),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_7 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=padding,groups=groups,bias=False),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_8 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=1,groups=groups,bias=False),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_9 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=2,groups=groups,bias=False,dilation=2),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_10 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=padding,groups=groups,bias=False),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_11 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=padding,groups=groups,bias=False),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_12 = nn.Sequential(nn.Conv2d(in_channels=features,out_channels=features,kernel_size=kernel_size,padding=1,groups=groups,bias=False),nn.BatchNorm2d(features),nn.ReLU(inplace=True))
        self.conv1_13 = nn.Conv2d(in_channels=features,out_channels=1,kernel_size=kernel_size,padding=1,groups=groups,bias=False)
        self.conv3 = nn.Conv2d(in_channels=2,out_channels=1,kernel_size=1,stride=1,padding=0,groups=1,bias=True)
        self.ReLU = nn.ReLU(inplace=True)
        self.Tanh= nn.Tanh()
        self.sigmoid = nn.Sigmoid()

        # for m in self.modules():
        #     if isinstance(m, nn.Conv2d):
        #         # n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
        #         m.weight.data.normal_(0, (2 / (9.0 * 64)) ** 0.5)
        #     if isinstance(m, nn.BatchNorm2d):
        #         m.weight.data.normal_(0, (2 / (9.0 * 64)) ** 0.5)
        #         clip_b = 0.025
        #         w = m.weight.data.shape[0]
        #         for j in range(w):
        #             if m.weight.data[j] >= 0 and m.weight.data[j] < clip_b:
        #                 m.weight.data[j] = clip_b
        #             elif m.weight.data[j] > -clip_b and m.weight.data[j] < 0:
        #                 m.weight.data[j] = -clip_b
        #         m.running_var.fill_(0.01)

    def forward(self, x):
        input = x
        x1 = self.conv1_1(x)
        x1 = self.conv1_2(x1)
        x1 = self.conv1_3(x1)
        x1 = self.conv1_4(x1)
        x1 = self.conv1_5(x1)
        x1 = self.conv1_6(x1)
        x1 = self.conv1_7(x1)
        x1 = self.conv1_8(x1)
        x1 = self.conv1_9(x1)
        x1 = self.conv1_10(x1)
        x1 = self.conv1_11(x1)
        x1 = self.conv1_12(x1)
        x1 = self.conv1_13(x1)
        out = torch.cat([input,x1],1)
        out= self.Tanh(out)
        # out = self.sigmoid(out)
        out = self.conv3(out)
        out = out*x1
        out2 = self.Tanh(out)
        out2 = input - out2


        return out2

class operation():
    def __init__(self, X, Y, CirS_kong, P, max_epoch=600, learning_rate=10**-3, device=None, alpha_tv = 1e-4, dtype=None):
        super(operation, self).__init__()
        if device is None:
            device = torch.device('cuda: 0' if torch.cuda.is_available() else 'cpu')
        self.X = X
        self.Y = Y
        self.CirS_kong = CirS_kong
        self.P = P
        self.learning_rate = learning_rate
        self.max_epoch = max_epoch
        self.device = device
        self.alpha_tv = alpha_tv
        self.dtype = dtype

    def MSE_TV_LOSS (self, x_pre, x, alpha, dtype):
        x_np = x_pre.detach().cpu().numpy()
        dx = np.diff(x_np, axis=0)
        dy = np.diff(x_np, axis=1)
        dx_padded = np.pad(dx, ((0, 1), (0, 0)), mode='constant', constant_values=0)
        dy_padded = np.pad(dy, ((0, 0), (0, 1)), mode='constant', constant_values=0)
        tv = np.sum(np.sqrt(dx_padded[:-1, :-1] ** 2 + dy_padded[:-1, :-1] ** 2 + 1e-10))

        selected_elements = x_pre.reshape(1024, 1)
        selected_elements.requires_grad_(True)
        mse = torch.nn.MSELoss(reduction='mean').type(dtype)
        predict_out = self.CirS_kong.matmul(selected_elements).t()
        mseloss = mse(predict_out, x)

        return mseloss + alpha*tv
        # return mseloss

    def run(self):
        model = ADNet(channels=1)
        optimizer = torch.optim.Adam(model.parameters(), lr=self.learning_rate)
        model.to(self.device)
        self.X = self.X.reshape(1, 1, 32, 32)
        output_dir = 'C:/Users/ASUS/Desktop/无监督_EIT/MTF_Code/lung'  # 保存模型的目录路径
        # epsilon = 0.1  # Threshold for loss stabilization procedure
        # L_pre = float("inf")
        # # sigma_pre = None
        theta_pre = None
        for epoch in range(self.max_epoch):
            recons = model(self.X)
            pre_recons = recons.reshape(32, 32)
            target = self.Y
            target.requires_grad_(True)
            loss = self.MSE_TV_LOSS(pre_recons, target, self.alpha_tv, self.dtype)
            # dif_loss = abs((loss - L_pre) / loss)
            # # dif_loss = (loss - L_pre) / loss
            # if dif_loss > epsilon and epoch > 0:
            #     print('Falling back to previous checkpoint.')
            #     # self.X = sigma_pre
            #     for new_param, net_param in zip(theta_pre, model.parameters()):
            #         net_param.data.copy_(new_param.cuda())
            # else:
            #     # sigma_pre = recons.clone().detach()
            #     L_pre = loss
            #     theta_pre = [x.cpu() for x in model.parameters()]


            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            print('epoch-%3d,' % epoch, 'loss: %6.5f' % loss.item())
        return recons

